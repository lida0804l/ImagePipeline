/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QCustomPlot *plot;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *btn_zoomFull;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QDoubleSpinBox *bx_x;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QDoubleSpinBox *bx_y;
    QPushButton *btn_add;
    QPushButton *btn_clear;

    void setupUi(QDialog *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        verticalLayout_2 = new QVBoxLayout(MainWindow);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        plot = new QCustomPlot(MainWindow);
        plot->setObjectName(QString::fromUtf8("plot"));

        verticalLayout->addWidget(plot);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        btn_zoomFull = new QPushButton(MainWindow);
        btn_zoomFull->setObjectName(QString::fromUtf8("btn_zoomFull"));

        horizontalLayout_3->addWidget(btn_zoomFull);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(MainWindow);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        bx_x = new QDoubleSpinBox(MainWindow);
        bx_x->setObjectName(QString::fromUtf8("bx_x"));

        horizontalLayout->addWidget(bx_x);


        horizontalLayout_3->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(MainWindow);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        bx_y = new QDoubleSpinBox(MainWindow);
        bx_y->setObjectName(QString::fromUtf8("bx_y"));

        horizontalLayout_2->addWidget(bx_y);


        horizontalLayout_3->addLayout(horizontalLayout_2);

        btn_add = new QPushButton(MainWindow);
        btn_add->setObjectName(QString::fromUtf8("btn_add"));

        horizontalLayout_3->addWidget(btn_add);

        btn_clear = new QPushButton(MainWindow);
        btn_clear->setObjectName(QString::fromUtf8("btn_clear"));

        horizontalLayout_3->addWidget(btn_clear);


        verticalLayout->addLayout(horizontalLayout_3);

        verticalLayout->setStretch(0, 10);
        verticalLayout->setStretch(1, 1);

        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QDialog *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        btn_zoomFull->setText(QApplication::translate("MainWindow", "Zoom Full", nullptr));
        label->setText(QApplication::translate("MainWindow", "X", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Y", nullptr));
        btn_add->setText(QApplication::translate("MainWindow", "Add", nullptr));
        btn_clear->setText(QApplication::translate("MainWindow", "Clear", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
