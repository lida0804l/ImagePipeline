#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDialog>
//#include <>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QDialog
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void add_Point(double x, double y);

    void clearData();

    void plot();

private slots:
    void on_btn_add_clicked();

    void on_btn_clear_clicked();

    void clickedGraph(QMouseEvent* event);

    void on_btn_zoomFull_clicked();

private:
    Ui::MainWindow *ui;

    QVector<double> qv_x, qv_y;

};
#endif // MAINWINDOW_H
